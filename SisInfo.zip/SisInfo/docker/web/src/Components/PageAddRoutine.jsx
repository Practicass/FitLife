import React from 'react'

const PageAddRoutine = () => {
  return (
    <div>
      
    </div>
  )
}

export default PageAddRoutine
