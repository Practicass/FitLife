import React from 'react'

const StepsRegister = () => {
    return (
        <div className='StepsRegister'>
            
        </div>
    )
}

export default StepsRegister
