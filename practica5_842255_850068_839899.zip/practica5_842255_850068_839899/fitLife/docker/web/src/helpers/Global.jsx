export const Global ={
    url: "http://localhost:3900/api/"
};