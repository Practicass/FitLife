import RouterPrincipal from './Router/RouterPrincipal'


function App() {
  

  return (
    <div className="general">
      <RouterPrincipal/>
    </div>
  )
}

export default App

// export default function App() {
//   return (
//     <h1 className="text-3xl font-bold underline">
//       Hello world!
//     </h1>
//   )
// }