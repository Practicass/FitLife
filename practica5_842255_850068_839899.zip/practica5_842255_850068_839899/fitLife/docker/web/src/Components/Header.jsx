
import Logo from './Logo'


import IconDropdown from './IconDropdown'


const Header = () => {




  return (
    <div className='header'>
      
        
        <Logo/>
        <IconDropdown/>
       
    </div>
  )
}

export default Header
